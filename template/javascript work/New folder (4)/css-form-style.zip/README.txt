A Pen created at CodePen.io. You can find this one at https://codepen.io/AmrSubZero/pen/jDxGE.

 CSS form style ready for use, code formatted well so you can use it easly. you can add you custom fields, enjoy.